<?php

declare(strict_types=1);

return [
    'next'     => 'Neste &raquo;',
    'previous' => '&laquo; Forrige',
];
