<?php

declare(strict_types=1);

return [
    'failed'   => 'De angivne oplysninger er ugyldige.',
    'password' => 'Adgangskoden er forkert.',
    'throttle' => 'For mange loginforsøg. Prøv igen om :seconds sekunder.',
];
