import.meta.glob([
    "../images/**",
    "../images/partiners/**",
    "../errors/**",
    "../errors/svgs/**",
]);

import "./bootstrap";
