<?php

declare(strict_types=1);

return [
    'next'     => 'Næste &raquo;',
    'previous' => '&laquo; Forrige',
];
