<?php

declare(strict_types=1);

return [
    'next'     => '下一頁 &raquo;',
    'previous' => '&laquo; 上一頁',
];
