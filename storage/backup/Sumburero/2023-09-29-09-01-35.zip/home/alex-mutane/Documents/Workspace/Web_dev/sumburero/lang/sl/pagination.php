<?php

declare(strict_types=1);

return [
    'next'     => 'Naslednja &raquo;',
    'previous' => '&laquo; Prejšnja',
];
