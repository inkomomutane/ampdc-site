<?php

declare(strict_types=1);

return [
    'failed'   => 'Ti podatki se ne ujemajo z našimi.',
    'password' => 'Greslo ni pravilno.',
    'throttle' => 'Preveč poskusov prijave. Prosimo, poskusite ponovno čez :seconds sekund.',
];
