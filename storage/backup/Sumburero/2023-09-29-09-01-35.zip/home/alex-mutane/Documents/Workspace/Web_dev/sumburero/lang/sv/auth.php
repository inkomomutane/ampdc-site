<?php

declare(strict_types=1);

return [
    'failed'   => 'Dessa uppgifter stämmer inte överens med vårt register.',
    'password' => 'Lösenordet är fel.',
    'throttle' => 'För många inloggningsförsök. Var vänlig försök igen om :seconds sekunder.',
];
