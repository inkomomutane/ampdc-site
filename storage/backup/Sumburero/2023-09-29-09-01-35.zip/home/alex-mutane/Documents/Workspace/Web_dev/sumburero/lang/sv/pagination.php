<?php

declare(strict_types=1);

return [
    'next'     => 'Nästa &raquo;',
    'previous' => '&laquo; Föregående',
];
