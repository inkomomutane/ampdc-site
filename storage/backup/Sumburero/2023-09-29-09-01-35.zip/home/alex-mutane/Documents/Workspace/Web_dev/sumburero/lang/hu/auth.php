<?php

declare(strict_types=1);

return [
    'failed'   => 'Rossz email-jelszó páros.',
    'password' => 'A(z) :attribute jelszónak kell, hogy legyen!',
    'throttle' => 'Túl sok próbálkozás. Kérjük próbálja újra :seconds másodperc múlva.',
];
