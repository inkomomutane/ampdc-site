<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class NavigationsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('navigations')->delete();
        
        
        
    }
}