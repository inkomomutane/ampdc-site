<?php

declare(strict_types=1);

return [
    'next'     => 'Seterusnya &raquo;',
    'previous' => '&laquo; Sebelumnya',
];
