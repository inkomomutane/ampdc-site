<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class GlobalSetVariablesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('global_set_variables')->delete();
        
        
        
    }
}