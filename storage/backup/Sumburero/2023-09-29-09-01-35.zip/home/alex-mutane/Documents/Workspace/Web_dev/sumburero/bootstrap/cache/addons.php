<?php return array (
  'statamic/eloquent-driver' => 
  array (
    'id' => 'statamic/eloquent-driver',
    'slug' => NULL,
    'editions' => 
    array (
    ),
    'marketplaceId' => NULL,
    'marketplaceSlug' => NULL,
    'marketplaceUrl' => NULL,
    'marketplaceSellerSlug' => NULL,
    'latestVersion' => NULL,
    'version' => '2.7.0',
    'namespace' => 'Statamic\\Eloquent',
    'autoload' => 'src',
    'provider' => 'Statamic\\Eloquent\\ServiceProvider',
    'name' => 'Eloquent Driver',
    'url' => NULL,
    'description' => 'Allows you to store Statamic data in a database.',
    'developer' => NULL,
    'developerUrl' => NULL,
    'email' => NULL,
  ),
);