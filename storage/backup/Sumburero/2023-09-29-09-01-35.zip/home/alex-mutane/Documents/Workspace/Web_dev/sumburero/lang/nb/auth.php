<?php

declare(strict_types=1);

return [
    'failed'   => 'Disse opplysningene samsvarer ikke med hva vi har lagret.',
    'password' => 'Passordet er feil.',
    'throttle' => 'For mange innloggingsforsøk. Vennligst prøv igjen om :seconds sekunder.',
];
