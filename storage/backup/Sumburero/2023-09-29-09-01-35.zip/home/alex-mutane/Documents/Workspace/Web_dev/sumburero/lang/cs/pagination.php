<?php

declare(strict_types=1);

return [
    'next'     => 'další &raquo;',
    'previous' => '&laquo; předchozí',
];
