<?php

declare(strict_types=1);

return [
    'next'     => 'Következő &raquo;',
    'previous' => '&laquo; Előző',
];
