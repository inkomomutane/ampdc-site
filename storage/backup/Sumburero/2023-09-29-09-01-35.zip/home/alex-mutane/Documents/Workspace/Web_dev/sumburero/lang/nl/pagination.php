<?php

declare(strict_types=1);

return [
    'next'     => 'Volgende &raquo;',
    'previous' => '&laquo; Vorige',
];
