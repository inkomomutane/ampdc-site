<?php

declare(strict_types=1);

return [
    'failed'   => 'Tyto přihlašovací údaje neodpovídají žadnému záznamu.',
    'password' => 'Heslo je nesprávné.',
    'throttle' => 'Příliš mnoho pokusů o přihlášení. Zkuste to prosím znovu za :seconds sekund.',
];
