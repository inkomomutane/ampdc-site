<?php

declare(strict_types=1);

return [
    'failed'   => 'Credenziali non valide.',
    'password' => 'Il campo :attribute non è corretto.',
    'throttle' => 'Troppi tentativi di accesso. Riprova tra :seconds secondi.',
];
