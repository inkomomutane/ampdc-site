<?php

declare(strict_types=1);

return [
    'failed'   => 'Butiran ini tidak sepadan dengan rekod kami.',
    'password' => 'Kata laluan tidak sah.',
    'throttle' => 'Terlalu banyak percubaan log masuk. Sila cuba lagi dalam :seconds saat.',
];
